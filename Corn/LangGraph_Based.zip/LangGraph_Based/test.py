from Graph import build_graph
from fastapi import FastAPI
import uvicorn


def main():

    app = build_graph()
    
    print("🌽 智能系统开始：支持图像路径 + 问题文字输入")

    while True:
        img = input("🖼️ 输入图像路径（可留空）：\n> ").strip()
        if img.lower() in ["", "无", "无图", "none", "no", "n"]:
            img = None

        txt = input("📝 输入问题（可留空）：\n> ").strip()
        if not txt or txt.lower() in ["", "无", "无图", "none", "no", "n"]:
            txt = None
            if not img:
                print("请至少提供图像或文本输入。")
                continue

        if txt.lower() in ["退出", "exit", "quit"]:
            print("再见！感谢使用玉米智能系统！")
            break

        if not img and not txt:
            print("请至少提供图像或文本输入。")
            continue

        # state = {
        #     "question": txt if txt else None
        # }

        state = {
        "question": txt,
        "image_path": img,
        "image_description": None,
        "detection_result": None,
        "answer": None,
        "need_medication": None,
        "decision": None
    }

        result = app.invoke(state)

        print("\n🤖 问答输出：", result.get("answer"))
        print("🔬 识别输出：", result.get("detection_result"))

        if result.get("answer") and input("\n💊 需要推荐农药吗？(y/n)：").lower() == "y":
            result = app.invoke({**result, "need_medication": True})
            print("\n✅ 农药建议：", result.get("decision"))
        else:
            print("🛑 无农药建议流程。")


if __name__ == "__main__":
    main()

# if __name__ == "__main__":
#     app = build_graph()

#     user_question = "玉米现在需要喷什么农药？"

#     result = app.invoke({
#         "question": user_question
#     })

#     print("\n✅ 最终输出建议：")
#     print(result["decision"])
