import requests
from utils import call_dify_agent
from config import  DETECTION_CHATFLOW_ID, DETECTION_API_KEY,QA_CHATFLOW_ID, QA_API_KEY, DECISION_CHATFLOW_ID, DECISION_API_KEY

# 模拟识别
def imitate_pest_detection_agent(state):
    # 模拟返回识别结果
    result = "发现玉米叶片有红蜘蛛和叶斑病症状。"
    print("[图像识别 Agent 输出]", result)
    state["image_description"] = result
    state["detection_result"] = result
    return state

# 识别智能体
def pest_detection_agent(state):
    # prompt = f"""
    # 请根据图像描述识别图像中的作物类型和疾病：
    # 图像描述：{state.get('image_description', '')}
    # 识别结果：
    # """
    prompt = "请识别图像中的病害和作物。"
    image_url = state.get("image_path", None)

    # 调用 Dify 识别智能体
    response = call_dify_agent(
        prompt.strip(),
        chatflow_id=DETECTION_CHATFLOW_ID,
        api_key=DETECTION_API_KEY,
        image_url=image_url
    )
    print("[识别 Agent 输出]", response)
    state["detection_result"] = response
    return state

# 问答智能体
def qa_agent(state):
    prompt = f"""
    图像描述：{state.get('image_description', '')}
    检测结果：{state.get('detection_result', '')}
    问题：{state.get('question', '')}
    请结合图像描述和检测结果回答问题：
    """
    # 调用 Dify 问答智能体
    response = call_dify_agent(
        prompt=prompt.strip(),
        chatflow_id=QA_CHATFLOW_ID,
        api_key=QA_API_KEY,
    )
    print("[问答 Agent 输出]", response)
    state["answer"] = response
    return state

# 决策智能体
def decision_agent(state):
    prompt = f"""
    图像描述：{state.get('image_description', '')}
    检测结果：{state.get('detection_result', '')}
    问题：{state.get('question', '')}
    请结合图像描述和检测结果回答问题：
    """
    # 调用 Dify 决策智能体
    response = call_dify_agent(
        prompt.strip(),
        chatflow_id=DECISION_CHATFLOW_ID,
        api_key=DECISION_API_KEY,
    )
    print("[决策 Agent 输出]", response)
    state["decision"] = response
    return state
