import { type NextRequest, NextResponse } from "next/server"

// 模拟天气数据获取函数
function getWeatherData(location: string) {
  // 这里可以集成真实的天气API，如OpenWeatherMap、和风天气等
  // 现在使用模拟数据
  const weatherConditions = ["晴天", "多云", "阴天", "小雨", "中雨"]
  const temperatures = ["15-20°C", "20-25°C", "25-30°C", "30-35°C"]
  const humidities = ["50-60%", "60-70%", "70-80%", "80-90%"]
  const windLevels = ["1-2级(软风)", "3-4级(轻风)", "5-6级(清风)"]

  // 基于地区名称生成相对稳定的"随机"数据
  const locationHash = location.split("").reduce((a, b) => {
    a = (a << 5) - a + b.charCodeAt(0)
    return a & a
  }, 0)

  const weather = weatherConditions[Math.abs(locationHash) % weatherConditions.length]
  const temperature = temperatures[Math.abs(locationHash >> 2) % temperatures.length]
  const humidity = humidities[Math.abs(locationHash >> 4) % humidities.length]
  const windLevel = windLevels[Math.abs(locationHash >> 6) % windLevels.length]

  return {
    temperature,
    humidity,
    weather,
    windLevel,
    description: `${location}当前${weather}，温度${temperature}，相对湿度${humidity}，风力${windLevel}。适宜进行田间作业。`,
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { location } = body

    if (!location) {
      return NextResponse.json({ error: "地区信息不能为空" }, { status: 400 })
    }

    // 这里可以调用真实的天气API
    // 例如：OpenWeatherMap API
    /*
    const apiKey = process.env.OPENWEATHER_API_KEY
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&appid=${apiKey}&units=metric&lang=zh_cn`
    )
    
    if (!response.ok) {
      throw new Error('天气API调用失败')
    }
    
    const data = await response.json()
    
    const weatherData = {
      temperature: `${Math.round(data.main.temp)}°C`,
      humidity: `${data.main.humidity}%`,
      weather: data.weather[0].description,
      windLevel: `${Math.round(data.wind.speed * 3.6)}km/h`,
      description: `${location}当前${data.weather[0].description}，温度${Math.round(data.main.temp)}°C`
    }
    */

    // 目前使用模拟数据
    const weatherData = getWeatherData(location)

    return NextResponse.json(weatherData)
  } catch (error) {
    console.error("Weather API Error:", error)
    return NextResponse.json({ error: "获取天气信息失败" }, { status: 500 })
  }
}
