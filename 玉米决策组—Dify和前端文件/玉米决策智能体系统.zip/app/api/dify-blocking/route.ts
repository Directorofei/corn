import { type NextRequest, NextResponse } from "next/server"

export const dynamic = "force-dynamic"

const DIFY_API = "https://api.dify.ai/v1/chat-messages"
const API_KEY = "app-5m7qs7XWIS2p4DiG1LR6l8QF"

export async function POST(req: NextRequest) {
  try {
    const { query, conversationId = "" } = await req.json()

    console.log("=== Dify Blocking Workflow API Call ===")
    console.log("API Key:", API_KEY)
    console.log("Query:", query)
    console.log("Using blocking mode with CHATFLOW workflow")

    const upstream = await fetch(DIFY_API, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: {},
        query,
        response_mode: "blocking",
        conversation_id: conversationId,
        user: "corn-pest-user",
      }),
      cache: "no-store",
    })

    const raw = await upstream.text()
    console.log("Workflow response received:", raw.substring(0, 200) + "...")

    let parsed: any = null
    try {
      parsed = JSON.parse(raw)
      console.log("Parsed workflow result:", {
        hasAnswer: !!parsed.answer,
        hasMessage: !!parsed.message,
        conversationId: parsed.conversation_id,
      })
    } catch {
      console.log("Response is not JSON, using raw text as workflow output")
    }

    if (!upstream.ok) {
      const message = parsed?.error ?? raw
      console.error("Workflow API error:", message)
      return NextResponse.json({ error: message }, { status: upstream.status })
    }

    const payload =
      parsed && typeof parsed === "object"
        ? {
            answer: parsed.answer ?? parsed.message ?? raw,
            conversationId: parsed.conversation_id ?? "",
            messageId: parsed.message_id ?? "",
          }
        : { answer: raw, conversationId: "", messageId: "" }

    console.log("Final workflow payload:", {
      answerLength: payload.answer?.length || 0,
      hasConversationId: !!payload.conversationId,
    })

    const res = NextResponse.json(payload)
    res.headers.set("Access-Control-Allow-Origin", "*")
    return res
  } catch (err) {
    console.error("Workflow proxy fatal error:", err)
    return NextResponse.json({ error: "工作流服务暂时不可用，请稍后再试" }, { status: 500 })
  }
}
