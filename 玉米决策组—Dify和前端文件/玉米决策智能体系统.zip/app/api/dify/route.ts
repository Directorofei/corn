import { type NextRequest, NextResponse } from "next/server"

/* Always run on the server, never cached */
export const dynamic = "force-dynamic"

const DIFY_API = "https://api.dify.ai/v1/chat-messages"
const API_KEY = "app-5m7qs7XWIS2p4DiG1LR6l8QF"

export async function POST(req: NextRequest) {
  try {
    const { query, conversationId = "" } = await req.json()

    console.log("=== Dify Workflow API Call Debug ===")
    console.log("API Key:", API_KEY)
    console.log("Query:", query)
    console.log("Conversation ID:", conversationId)
    console.log("Request URL:", DIFY_API)
    console.log("Using CHATFLOW workflow endpoint")

    const requestBody = {
      inputs: {},
      query,
      response_mode: "streaming", // 改为streaming模式，提高响应速度
      conversation_id: conversationId,
      user: "corn-pest-user",
    }

    console.log("Request Body:", JSON.stringify(requestBody, null, 2))

    const startTime = Date.now()

    const upstream = await fetch(DIFY_API, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
      // Disable Next.js fetch caching completely
      cache: "no-store",
    })

    const fetchTime = Date.now() - startTime
    console.log("Fetch time:", fetchTime + "ms")
    console.log("Response status:", upstream.status)
    console.log("Response headers:", Object.fromEntries(upstream.headers.entries()))

    // ---- read & forward Dify response safely -----------------------------------
    const raw = await upstream.text()
    const parseTime = Date.now() - startTime
    console.log("Total time:", parseTime + "ms")
    console.log("Raw response:", raw.substring(0, 500) + "...")
    console.log("Response appears to be from Dify workflow:", raw.includes("answer") || raw.includes("message"))

    let parsed: any = null

    try {
      // 如果是streaming响应，需要特殊处理
      if (raw.includes("data: ")) {
        // 处理Server-Sent Events格式
        const lines = raw.split("\n").filter((line) => line.startsWith("data: "))
        const lastDataLine = lines[lines.length - 1]
        if (lastDataLine && lastDataLine !== "data: [DONE]") {
          const jsonStr = lastDataLine.replace("data: ", "")
          parsed = JSON.parse(jsonStr)
        }
      } else {
        parsed = JSON.parse(raw)
      }
    } catch (parseError) {
      console.error("JSON parse error:", parseError)
      console.log("Raw response that failed to parse:", raw)
    }

    if (!upstream.ok) {
      const message = parsed?.error ?? raw
      console.error("Dify API error:", message)
      return NextResponse.json({ error: message }, { status: upstream.status })
    }

    /* 200-series: if JSON use the expected fields, otherwise wrap the raw text */
    const payload =
      parsed && typeof parsed === "object"
        ? {
            answer: parsed.answer ?? parsed.message ?? raw,
            conversationId: parsed.conversation_id ?? "",
            messageId: parsed.message_id ?? "",
          }
        : { answer: raw, conversationId: "", messageId: "" }

    console.log("Final payload:", payload)

    const res = NextResponse.json(payload)
    res.headers.set("Access-Control-Allow-Origin", "*")
    return res
    // ----------------------------------------------------------------------------
  } catch (err) {
    console.error("Proxy error:", err)
    console.error("Error stack:", err instanceof Error ? err.stack : "No stack trace")
    return NextResponse.json({ error: "服务器暂时不可用，请稍后再试" }, { status: 500 })
  }
}
