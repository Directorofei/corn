import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { query, conversationId } = body

    console.log("Sending query to Dify:", query)
    console.log("Conversation ID:", conversationId)

    // 使用Dify CHATFLOW API
    const response = await fetch("https://api.dify.ai/v1/chat-messages", {
      method: "POST",
      headers: {
        Authorization: "Bearer app-5m7qs7XWIS2p4DiG1LR6l8QF",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: {},
        query: query,
        response_mode: "blocking",
        conversation_id: conversationId || "",
        user: "corn-pest-user",
      }),
    })

    if (!response.ok) {
      const text = await response.text()
      console.error("Dify API Error Response:", text)
      throw new Error(`Dify API error ${response.status}: ${text}`)
    }

    const data = await response.json()
    console.log("Dify API Response:", data)

    return NextResponse.json({
      answer: data.answer,
      conversation_id: data.conversation_id,
      message_id: data.message_id,
    })
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "服务暂时不可用，请稍后重试",
      },
      { status: 500 },
    )
  }
}
