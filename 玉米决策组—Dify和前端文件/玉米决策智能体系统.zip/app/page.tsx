"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import {
  AlertCircle,
  Bug,
  Calendar,
  Trash2,
  History,
  Send,
  Loader2,
  MapPin,
  RefreshCw,
  LogIn,
  LogOut,
  User,
  MessageCircle,
  Settings,
  Bot,
  AlertTriangle,
  CheckSquare,
  Square,
} from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface FormData {
  pestType: string
  growthStage: string
  location: string
}

interface ChatMessage {
  id: string
  type: "user" | "assistant"
  content: string
  timestamp: string
}

interface ChatSession {
  id: string
  title: string
  messages: ChatMessage[]
  conversationId: string
  timestamp: string
}

interface QueryRecord {
  id: string
  timestamp: string
  pestType?: string
  growthStage?: string
  location?: string
  question?: string
  result: string
  systemType: "condition" | "qa"
}

interface LoginData {
  username: string
  password: string
}

type SystemType = "condition" | "qa"

// ==== Dify helper ====================================================
/* 调用本地代理，避免 CORS 与浏览器限制 */
async function callDify(query: string, conversationId = "") {
  // 首先尝试blocking模式，通常更快
  try {
    const res = await fetch("/api/dify-blocking", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, conversationId }),
    })

    if (res.ok) {
      return (await res.json()) as {
        answer: string
        conversationId: string
        messageId: string
      }
    }
  } catch (error) {
    console.log("Blocking mode failed, trying streaming mode:", error)
  }

  // 如果blocking失败，尝试streaming模式
  const res = await fetch("/api/dify", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, conversationId }),
  })

  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Dify API ${res.status}: ${text}`)
  }

  return res.json() as Promise<{
    answer: string
    conversationId: string
    messageId: string
  }>
}

export default function CornPestDecisionSystem() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [currentUser, setCurrentUser] = useState("")
  const [systemType, setSystemType] = useState<SystemType>("condition")
  const [loginData, setLoginData] = useState<LoginData>({
    username: "",
    password: "",
  })
  const [loginError, setLoginError] = useState("")
  const [isLoggingIn, setIsLoggingIn] = useState(false)
  const [rememberPassword, setRememberPassword] = useState(false)

  // 条件选择系统状态
  const [formData, setFormData] = useState<FormData>({
    pestType: "",
    growthStage: "",
    location: "",
  })

  // 问答系统状态
  const [currentQuestion, setCurrentQuestion] = useState("")
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([])
  const [currentSessionId, setCurrentSessionId] = useState<string>("")
  const [currentMessages, setCurrentMessages] = useState<ChatMessage[]>([])
  const [conversationId, setConversationId] = useState("")

  // 批量删除相关状态
  const [selectedSessions, setSelectedSessions] = useState<Set<string>>(new Set())
  const [isSelectionMode, setIsSelectionMode] = useState(false)

  const [isLoading, setIsLoading] = useState(false)
  const [currentResult, setCurrentResult] = useState<string>("")
  const [queryHistory, setQueryHistory] = useState<QueryRecord[]>([])
  const [error, setError] = useState<string>("")

  const messagesEndRef = useRef<HTMLDivElement>(null)

  // 滚动到底部
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [currentMessages])

  // 检查登录状态
  useEffect(() => {
    const savedLoginState = localStorage.getItem("corn-pest-login")
    if (savedLoginState) {
      const loginState = JSON.parse(savedLoginState)
      setIsLoggedIn(true)
      setCurrentUser(loginState.username)
      setSystemType(loginState.systemType || "condition")
    }

    // 检查保存的账号密码
    const savedCredentials = localStorage.getItem("corn-pest-credentials")
    if (savedCredentials) {
      try {
        const credentials = JSON.parse(savedCredentials)
        setLoginData({
          username: credentials.username || "",
          password: atob(credentials.password || ""), // 简单解码
        })
        setRememberPassword(true)
      } catch (error) {
        console.error("Failed to load saved credentials:", error)
      }
    }
  }, [])

  // 从本地存储加载数据
  useEffect(() => {
    if (!isLoggedIn) return

    if (systemType === "condition") {
      const savedHistory = localStorage.getItem(`corn-pest-history-${systemType}`)
      if (savedHistory) {
        setQueryHistory(JSON.parse(savedHistory))
      }

      const lastSession = localStorage.getItem(`corn-pest-last-session-${systemType}`)
      if (lastSession) {
        const sessionData = JSON.parse(lastSession)
        setFormData({
          pestType: sessionData.formData?.pestType ?? "",
          growthStage: sessionData.formData?.growthStage ?? "",
          location: sessionData.formData?.location ?? "",
        })
        setCurrentResult(sessionData.result || "")
      }
    } else {
      // 加载聊天会话
      const savedSessions = localStorage.getItem("corn-pest-chat-sessions")
      if (savedSessions) {
        const sessions = JSON.parse(savedSessions)
        setChatSessions(sessions)
        if (sessions.length > 0) {
          const lastSession = sessions[0]
          setCurrentSessionId(lastSession.id)
          setCurrentMessages(lastSession.messages)
          setConversationId(lastSession.conversationId)
        }
      }
    }
  }, [isLoggedIn, systemType])

  // 保存聊天会话
  const saveChatSessions = (sessions: ChatSession[]) => {
    localStorage.setItem("corn-pest-chat-sessions", JSON.stringify(sessions))
  }

  // 创建新的聊天会话
  const createNewChatSession = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: "新对话",
      messages: [],
      conversationId: "",
      timestamp: new Date().toLocaleString("zh-CN"),
    }
    const updatedSessions = [newSession, ...chatSessions]
    setChatSessions(updatedSessions)
    setCurrentSessionId(newSession.id)
    setCurrentMessages([])
    setConversationId("")
    saveChatSessions(updatedSessions)

    // 退出选择模式
    setIsSelectionMode(false)
    setSelectedSessions(new Set())
  }

  // 切换聊天会话
  const switchChatSession = (sessionId: string) => {
    const session = chatSessions.find((s) => s.id === sessionId)
    if (session) {
      setCurrentSessionId(sessionId)
      setCurrentMessages(session.messages)
      setConversationId(session.conversationId)
    }
  }

  // 删除单个聊天会话
  const deleteChatSession = (sessionId: string) => {
    const updatedSessions = chatSessions.filter((s) => s.id !== sessionId)
    setChatSessions(updatedSessions)
    saveChatSessions(updatedSessions)

    if (sessionId === currentSessionId) {
      if (updatedSessions.length > 0) {
        switchChatSession(updatedSessions[0].id)
      } else {
        createNewChatSession()
      }
    }
  }

  // 清空所有历史对话
  const clearAllChatSessions = () => {
    setChatSessions([])
    setCurrentSessionId("")
    setCurrentMessages([])
    setConversationId("")
    saveChatSessions([])
    setIsSelectionMode(false)
    setSelectedSessions(new Set())
    createNewChatSession()
  }

  // 切换选择模式
  const toggleSelectionMode = () => {
    setIsSelectionMode(!isSelectionMode)
    setSelectedSessions(new Set())
  }

  // 切换会话选择状态
  const toggleSessionSelection = (sessionId: string) => {
    const newSelected = new Set(selectedSessions)
    if (newSelected.has(sessionId)) {
      newSelected.delete(sessionId)
    } else {
      newSelected.add(sessionId)
    }
    setSelectedSessions(newSelected)
  }

  // 全选/取消全选
  const toggleSelectAll = () => {
    if (selectedSessions.size === chatSessions.length) {
      setSelectedSessions(new Set())
    } else {
      setSelectedSessions(new Set(chatSessions.map((s) => s.id)))
    }
  }

  // 批量删除选中的会话
  const deleteSelectedSessions = () => {
    const updatedSessions = chatSessions.filter((s) => !selectedSessions.has(s.id))
    setChatSessions(updatedSessions)
    saveChatSessions(updatedSessions)

    // 如果当前会话被删除，切换到第一个剩余会话
    if (selectedSessions.has(currentSessionId)) {
      if (updatedSessions.length > 0) {
        switchChatSession(updatedSessions[0].id)
      } else {
        createNewChatSession()
      }
    }

    setSelectedSessions(new Set())
    setIsSelectionMode(false)
  }

  // 登录处理
  const handleLogin = async (selectedSystemType: SystemType) => {
    if (!loginData.username || !loginData.password) {
      setLoginError("请输入用户名和密码")
      return
    }

    setIsLoggingIn(true)
    setLoginError("")

    setTimeout(() => {
      setIsLoggedIn(true)
      setCurrentUser(loginData.username)
      setSystemType(selectedSystemType)

      // 保存登录状态
      localStorage.setItem(
        "corn-pest-login",
        JSON.stringify({
          username: loginData.username,
          systemType: selectedSystemType,
          loginTime: new Date().toISOString(),
        }),
      )

      // 保存账号密码（如果用户选择记住）
      if (rememberPassword) {
        localStorage.setItem(
          "corn-pest-credentials",
          JSON.stringify({
            username: loginData.username,
            password: btoa(loginData.password), // 简单编码
          }),
        )
      } else {
        // 如果不记住密码，清除之前保存的
        localStorage.removeItem("corn-pest-credentials")
      }

      setIsLoggingIn(false)
    }, 1000)
  }

  // 登出处理
  const handleLogout = () => {
    setIsLoggedIn(false)
    setCurrentUser("")
    setLoginData({ username: "", password: "" })
    setSystemType("condition")
    setRememberPassword(false)
    localStorage.removeItem("corn-pest-login")

    // 询问是否清除保存的密码
    const shouldClearCredentials = window.confirm("是否同时清除保存的账号密码？")
    if (shouldClearCredentials) {
      localStorage.removeItem("corn-pest-credentials")
    }
  }

  // 系统切换处理
  const handleSystemSwitch = () => {
    const newSystemType = systemType === "condition" ? "qa" : "condition"
    setSystemType(newSystemType)

    // 更新登录状态中的系统类型
    const savedLoginState = localStorage.getItem("corn-pest-login")
    if (savedLoginState) {
      const loginState = JSON.parse(savedLoginState)
      loginState.systemType = newSystemType
      localStorage.setItem("corn-pest-login", JSON.stringify(loginState))
    }

    // 清除当前错误状态
    setError("")

    // 根据新系统类型初始化状态
    if (newSystemType === "condition") {
      // 切换到条件选择系统时，加载历史数据
      const savedHistory = localStorage.getItem(`corn-pest-history-condition`)
      if (savedHistory) {
        setQueryHistory(JSON.parse(savedHistory))
      } else {
        setQueryHistory([])
      }

      const lastSession = localStorage.getItem(`corn-pest-last-session-condition`)
      if (lastSession) {
        const sessionData = JSON.parse(lastSession)
        setFormData({
          pestType: sessionData.formData?.pestType ?? "",
          growthStage: sessionData.formData?.growthStage ?? "",
          location: sessionData.formData?.location ?? "",
        })
        setCurrentResult(sessionData.result || "")
      } else {
        setFormData({ pestType: "", growthStage: "", location: "" })
        setCurrentResult("")
      }
    } else {
      // 切换到问答系统时，加载聊天会话
      const savedSessions = localStorage.getItem("corn-pest-chat-sessions")
      if (savedSessions) {
        const sessions = JSON.parse(savedSessions)
        setChatSessions(sessions)
        if (sessions.length > 0) {
          const lastSession = sessions[0]
          setCurrentSessionId(lastSession.id)
          setCurrentMessages(lastSession.messages)
          setConversationId(lastSession.conversationId)
        } else {
          setCurrentSessionId("")
          setCurrentMessages([])
          setConversationId("")
        }
      } else {
        setChatSessions([])
        setCurrentSessionId("")
        setCurrentMessages([])
        setConversationId("")
      }
      setCurrentQuestion("")
    }
  }

  // 登录输入处理
  const handleLoginInputChange = (field: keyof LoginData, value: string) => {
    setLoginData({ ...loginData, [field]: value })
  }

  // 保存到本地存储（条件选择系统）
  const saveToLocalStorage = (history: QueryRecord[], session?: any) => {
    localStorage.setItem(`corn-pest-history-${systemType}`, JSON.stringify(history))
    if (session) {
      localStorage.setItem(`corn-pest-last-session-${systemType}`, JSON.stringify(session))
    }
  }

  const handleInputChange = (field: keyof FormData, value: string) => {
    const newFormData = { ...formData, [field]: value }
    setFormData(newFormData)
    saveToLocalStorage(queryHistory, { formData: newFormData, result: currentResult })
  }

  // 发送聊天消息
  const handleSendMessage = async () => {
    if (!currentQuestion.trim()) {
      setError("请输入您的问题")
      return
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: "user",
      content: currentQuestion.trim(),
      timestamp: new Date().toLocaleString("zh-CN"),
    }

    // 如果没有当前会话，创建新会话
    if (!currentSessionId) {
      createNewChatSession()
    }

    const updatedMessages = [...currentMessages, userMessage]
    setCurrentMessages(updatedMessages)
    setCurrentQuestion("")
    setIsLoading(true)
    setError("")

    try {
      const data = await callDify(userMessage.content, conversationId)

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: data.answer || "暂无回答",
        timestamp: new Date().toLocaleString("zh-CN"),
      }

      const finalMessages = [...updatedMessages, assistantMessage]
      setCurrentMessages(finalMessages)

      // 更新会话
      const updatedSessions = chatSessions.map((session) => {
        if (session.id === currentSessionId) {
          return {
            ...session,
            messages: finalMessages,
            conversationId: data.conversationId || conversationId,
            title: session.title === "新对话" ? userMessage.content.slice(0, 20) + "..." : session.title,
          }
        }
        return session
      })

      setChatSessions(updatedSessions)
      setConversationId(data.conversationId || conversationId)
      saveChatSessions(updatedSessions)
    } catch (err) {
      console.error("Send message error:", err)
      setError(err instanceof Error ? err.message : "发生未知错误")
    } finally {
      setIsLoading(false)
    }
  }

  // 条件选择系统提交
  const handleConditionSubmit = async () => {
    if (!formData.pestType || !formData.growthStage || !formData.location) {
      setError("请填写所有必要信息：病虫害类型、生长期和地点")
      return
    }

    const queryText = `病虫害类型：${formData.pestType}，生长期：${formData.growthStage}，地点：${formData.location}`

    setIsLoading(true)
    setError("")
    setCurrentResult("")

    try {
      const data = await callDify(queryText)
      const result = data.answer || "暂无决策建议"

      // 立即显示结果
      setCurrentResult(result)

      const newRecord: QueryRecord = {
        id: Date.now().toString(),
        timestamp: new Date().toLocaleString("zh-CN"),
        pestType: formData.pestType,
        growthStage: formData.growthStage,
        location: formData.location,
        result: result,
        systemType: "condition",
      }

      const updatedHistory = [newRecord, ...queryHistory].slice(0, 20)
      setQueryHistory(updatedHistory)
      saveToLocalStorage(updatedHistory, { formData, result })
    } catch (err) {
      console.error("Submit error:", err)
      setError(err instanceof Error ? err.message : "发生未知错误")
    } finally {
      setIsLoading(false)
    }
  }

  const deleteHistoryItem = (id: string) => {
    const updatedHistory = queryHistory.filter((item) => item.id !== id)
    setQueryHistory(updatedHistory)
    saveToLocalStorage(updatedHistory)
  }

  const loadHistoryItem = (record: QueryRecord) => {
    const newFormData = {
      pestType: record.pestType ?? "",
      growthStage: record.growthStage ?? "",
      location: record.location ?? "",
    }
    setFormData(newFormData)
    setCurrentResult(record.result)
    saveToLocalStorage(queryHistory, { formData: newFormData, result: record.result })
  }

  const handleRefresh = () => {
    if (systemType === "condition") {
      const emptyFormData = {
        pestType: "",
        growthStage: "",
        location: "",
      }
      setFormData(emptyFormData)
      setCurrentResult("")
      localStorage.removeItem(`corn-pest-last-session-${systemType}`)
    } else {
      createNewChatSession()
    }
    setError("")
  }

  // 如果未登录，显示登录界面
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="container mx-auto px-4 py-8 max-w-2xl">
          {/* 登录头部 */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2 flex items-center justify-center gap-3">
              <Bug className="h-10 w-10 text-emerald-400" />
              系统登录
            </h1>
            <p className="text-slate-300 text-lg">玉米病虫害智能决策系统</p>
          </div>

          {/* 登录表单 */}
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm mb-6">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <LogIn className="h-5 w-5 text-blue-400" />
                用户登录
              </CardTitle>
              <CardDescription className="text-slate-300">请输入您的账号和密码登录系统</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {loginError && (
                <Alert className="border-red-500/50 bg-red-500/10">
                  <AlertCircle className="h-4 w-4 text-red-400" />
                  <AlertDescription className="text-red-300">{loginError}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="username" className="text-white flex items-center gap-2">
                  <User className="h-4 w-4 text-emerald-400" />
                  用户名
                </Label>
                <Input
                  id="username"
                  placeholder="请输入用户名"
                  value={loginData.username}
                  onChange={(e) => handleLoginInputChange("username", e.target.value)}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                  onKeyPress={(e) => e.key === "Enter" && handleLogin("condition")}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-white flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-red-400" />
                  密码
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="请输入密码"
                  value={loginData.password}
                  onChange={(e) => handleLoginInputChange("password", e.target.value)}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                  onKeyPress={(e) => e.key === "Enter" && handleLogin("condition")}
                />
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="rememberPassword"
                  checked={rememberPassword}
                  onChange={(e) => setRememberPassword(e.target.checked)}
                  className="w-4 h-4 text-blue-600 bg-slate-700 border-slate-600 rounded focus:ring-blue-500 focus:ring-2"
                />
                <Label htmlFor="rememberPassword" className="text-slate-300 text-sm cursor-pointer">
                  记住密码
                </Label>
              </div>

              <div className="text-center text-sm text-slate-400 space-y-1">
                <p>提示：可使用任意用户名和密码登录</p>
                <p>勾选"记住密码"可在下次自动填充登录信息</p>
              </div>
            </CardContent>
          </Card>

          {/* 系统选择 */}
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings className="h-5 w-5 text-emerald-400" />
                选择系统类型
              </CardTitle>
              <CardDescription className="text-slate-300">请选择您要使用的系统类型</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <Button
                  onClick={() => handleLogin("condition")}
                  disabled={isLoggingIn}
                  className="h-24 bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 text-white font-semibold flex flex-col items-center justify-center gap-2"
                >
                  {isLoggingIn ? (
                    <Loader2 className="h-6 w-6 animate-spin" />
                  ) : (
                    <>
                      <Bug className="h-6 w-6" />
                      <span>条件选择系统</span>
                      <span className="text-xs opacity-80">选择病虫害类型、生长期等</span>
                    </>
                  )}
                </Button>

                <Button
                  onClick={() => handleLogin("qa")}
                  disabled={isLoggingIn}
                  className="h-24 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-semibold flex flex-col items-center justify-center gap-2"
                >
                  {isLoggingIn ? (
                    <Loader2 className="h-6 w-6 animate-spin" />
                  ) : (
                    <>
                      <MessageCircle className="h-6 w-6" />
                      <span>智能问答系统</span>
                      <span className="text-xs opacity-80">自由对话，支持追问</span>
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // 已登录，显示对应系统界面
  if (systemType === "condition") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="container mx-auto px-4 py-8">
          {/* 头部 */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-between mb-4">
              <div></div>
              <h1 className="text-4xl font-bold text-white flex items-center gap-3">
                <Bug className="h-10 w-10 text-emerald-400" />
                玉米病虫害智能决策系统
              </h1>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-slate-300 text-sm">欢迎回来</p>
                  <p className="text-white font-semibold">{currentUser}</p>
                </div>
                <Button
                  onClick={handleSystemSwitch}
                  variant="outline"
                  size="sm"
                  className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50 hover:text-white"
                >
                  <MessageCircle className="mr-2 h-4 w-4" />
                  切换到问答系统
                </Button>
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                  className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50 hover:text-white"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  退出
                </Button>
              </div>
            </div>
            <p className="text-slate-300 text-lg">基于AI的精准防治策略推荐</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* 用户输入区 */}
            <div className="lg:col-span-2">
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-blue-400" />
                    病虫害信息输入
                  </CardTitle>
                  <CardDescription className="text-slate-300">
                    请填写玉米病虫害相关信息，获得专业的防治建议
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {error && (
                    <Alert className="border-red-500/50 bg-red-500/10">
                      <AlertCircle className="h-4 w-4 text-red-400" />
                      <AlertDescription className="text-red-300">{error}</AlertDescription>
                    </Alert>
                  )}

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="pestType" className="text-white flex items-center gap-2">
                        <Bug className="h-4 w-4 text-emerald-400" />
                        病虫害类型 *
                      </Label>
                      <Select
                        value={formData.pestType || undefined}
                        onValueChange={(value) => handleInputChange("pestType", value)}
                      >
                        <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                          <SelectValue placeholder="选择病虫害类型" />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 border-slate-600">
                          <SelectItem value="玉米斑病">玉米斑病</SelectItem>
                          <SelectItem value="玉米锈病">玉米锈病</SelectItem>
                          <SelectItem value="玉米黑粉病">玉米黑粉病</SelectItem>
                          <SelectItem value="玉米黏虫">玉米黏虫</SelectItem>
                          <SelectItem value="玉米螟(钻心虫)">玉米螟(钻心虫)</SelectItem>
                          <SelectItem value="玉米蓟马">玉米蓟马</SelectItem>
                          <SelectItem value="玉米根腐病">玉米根腐病</SelectItem>
                          <SelectItem value="玉米苗枯病">玉米苗枯病</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="growthStage" className="text-white flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-green-400" />
                        生长期 *
                      </Label>
                      <Select
                        value={formData.growthStage || undefined}
                        onValueChange={(value) => handleInputChange("growthStage", value)}
                      >
                        <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                          <SelectValue placeholder="选择生长期" />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 border-slate-600">
                          <SelectItem value="苗期">苗期</SelectItem>
                          <SelectItem value="拔节期">拔节期</SelectItem>
                          <SelectItem value="抽雄期">抽雄期</SelectItem>
                          <SelectItem value="灌浆期">灌浆期</SelectItem>
                          <SelectItem value="成熟期">成熟期</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location" className="text-white flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-red-400" />
                      地点 *
                    </Label>
                    <Input
                      id="location"
                      placeholder="请输入具体地点，如：北京市、上海市、济南市等"
                      value={formData.location}
                      onChange={(e) => handleInputChange("location", e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                    />
                  </div>

                  <div className="flex gap-4">
                    <Button
                      onClick={handleConditionSubmit}
                      disabled={isLoading}
                      className="flex-1 bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 text-white font-semibold py-3"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          正在分析...
                        </>
                      ) : (
                        <>
                          <Send className="mr-2 h-4 w-4" />
                          获取防治建议
                        </>
                      )}
                    </Button>

                    <Button
                      onClick={handleRefresh}
                      disabled={isLoading}
                      variant="outline"
                      className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50 hover:text-white px-6"
                    >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      刷新
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* 结果展示区 */}
              {currentResult && (
                <Card className="mt-6 bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-emerald-400" />
                      防治策略建议
                    </CardTitle>
                    <CardDescription className="text-slate-300">基于病虫害情况的专业建议</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-slate-700/30 rounded-lg p-4 border border-slate-600">
                      <pre className="text-slate-200 whitespace-pre-wrap font-sans leading-relaxed">
                        {currentResult}
                      </pre>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* 历史记录面板 */}
            <div>
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <History className="h-5 w-5 text-blue-400" />
                    查询历史
                  </CardTitle>
                  <CardDescription className="text-slate-300">点击历史记录可重新加载查询</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[600px] pr-4">
                    {queryHistory.length === 0 ? (
                      <div className="text-center text-slate-400 py-8">
                        <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>暂无查询历史</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {queryHistory.map((record, index) => (
                          <div key={record.id}>
                            <div
                              className="bg-slate-700/30 rounded-lg p-4 border border-slate-600 hover:border-slate-500 transition-colors cursor-pointer group"
                              onClick={() => loadHistoryItem(record)}
                            >
                              <div className="flex items-start justify-between mb-2">
                                <Badge
                                  variant="secondary"
                                  className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                                >
                                  {record.pestType}
                                </Badge>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    deleteHistoryItem(record.id)
                                  }}
                                  className="opacity-0 group-hover:opacity-100 transition-opacity text-red-400 hover:text-red-300 hover:bg-red-500/10"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                              <div className="text-sm text-slate-300 space-y-1">
                                <p>
                                  <span className="text-slate-400">病虫害:</span> {record.pestType}
                                </p>
                                <p>
                                  <span className="text-slate-400">生长期:</span> {record.growthStage}
                                </p>
                                <p>
                                  <span className="text-slate-400">地点:</span> {record.location}
                                </p>
                              </div>
                              <div className="text-xs text-slate-500 mt-2 flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {record.timestamp}
                              </div>
                            </div>
                            {index < queryHistory.length - 1 && <Separator className="bg-slate-600" />}
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // 问答系统界面
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* 头部 */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button onClick={createNewChatSession} size="sm" className="bg-blue-500 hover:bg-blue-600 text-white">
                <MessageCircle className="mr-2 h-4 w-4" />
                新对话
              </Button>
            </div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <MessageCircle className="h-8 w-8 text-blue-400" />
              玉米病虫害智能问答
            </h1>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-slate-300 text-sm">欢迎回来</p>
                <p className="text-white font-semibold">{currentUser}</p>
              </div>
              <Button
                onClick={handleSystemSwitch}
                variant="outline"
                size="sm"
                className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50 hover:text-white"
              >
                <Bug className="mr-2 h-4 w-4" />
                切换到条件系统
              </Button>
              <Button
                onClick={handleLogout}
                variant="outline"
                size="sm"
                className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50 hover:text-white"
              >
                <LogOut className="mr-2 h-4 w-4" />
                退出
              </Button>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* 主对话区域 */}
          <div className="lg:col-span-3">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardContent className="p-0">
                {/* 对话消息区域 - 固定高度，内部滚动 */}
                <div className="h-[600px] flex flex-col">
                  <ScrollArea className="flex-1 px-6 py-4">
                    <div className="space-y-6">
                      {currentMessages.length === 0 ? (
                        <div className="text-center text-slate-400 py-20">
                          <Bot className="h-20 w-20 mx-auto mb-6 opacity-50" />
                          <p className="text-xl mb-3">欢迎使用玉米病虫害智能问答系统</p>
                          <p className="text-sm opacity-80">您可以询问任何关于玉米病虫害的问题，我会为您提供专业解答</p>
                        </div>
                      ) : (
                        currentMessages.map((message) => (
                          <div key={message.id} className="w-full">
                            {message.type === "user" ? (
                              // 用户消息 - 右对齐蓝色气泡
                              <div className="flex justify-end mb-4">
                                <div className="flex items-end gap-3 max-w-[80%]">
                                  <div className="bg-blue-500 text-white rounded-2xl rounded-br-md px-4 py-3">
                                    <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                                      {message.content}
                                    </pre>
                                    <p className="text-xs text-blue-100 mt-2 opacity-80">{message.timestamp}</p>
                                  </div>
                                  <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center flex-shrink-0">
                                    <User className="h-4 w-4 text-white" />
                                  </div>
                                </div>
                              </div>
                            ) : (
                              // AI消息 - 左对齐深色气泡
                              <div className="flex justify-start mb-4">
                                <div className="flex items-start gap-3 max-w-[85%]">
                                  <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0 mt-1">
                                    <Bot className="h-4 w-4 text-white" />
                                  </div>
                                  <div className="bg-slate-700/60 text-slate-100 rounded-2xl rounded-bl-md px-4 py-3 border border-slate-600/50">
                                    <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                                      {message.content}
                                    </pre>
                                    <p className="text-xs text-slate-400 mt-2">{message.timestamp}</p>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        ))
                      )}
                      {isLoading && (
                        <div className="flex justify-start mb-4">
                          <div className="flex items-start gap-3 max-w-[85%]">
                            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0 mt-1">
                              <Bot className="h-4 w-4 text-white" />
                            </div>
                            <div className="bg-slate-700/60 text-slate-100 rounded-2xl rounded-bl-md px-4 py-3 border border-slate-600/50">
                              <div className="flex items-center gap-2">
                                <Loader2 className="h-4 w-4 animate-spin" />
                                <span className="text-sm">正在思考中...</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                  </ScrollArea>

                  {/* 输入区域 - 固定在底部 */}
                  <div className="border-t border-slate-600 p-4 bg-slate-800/30">
                    {error && (
                      <Alert className="border-red-500/50 bg-red-500/10 mb-4">
                        <AlertCircle className="h-4 w-4 text-red-400" />
                        <AlertDescription className="text-red-300">{error}</AlertDescription>
                      </Alert>
                    )}

                    <div className="flex gap-3 items-end">
                      <div className="flex-1">
                        <Textarea
                          placeholder="请输入您的问题，支持追问..."
                          value={currentQuestion}
                          onChange={(e) => setCurrentQuestion(e.target.value)}
                          className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 resize-none min-h-[60px] max-h-[120px]"
                          onKeyPress={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                              e.preventDefault()
                              handleSendMessage()
                            }
                          }}
                        />
                      </div>
                      <Button
                        onClick={handleSendMessage}
                        disabled={isLoading || !currentQuestion.trim()}
                        className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-semibold px-6 py-3 h-[60px]"
                      >
                        {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
                      </Button>
                    </div>

                    <p className="text-xs text-slate-400 text-center mt-2">按 Enter 发送消息，Shift + Enter 换行</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 历史对话面板 */}
          <div className="lg:col-span-1">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white flex items-center gap-2">
                    <History className="h-5 w-5 text-blue-400" />
                    历史对话
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    {!isSelectionMode ? (
                      <>
                        <Button
                          onClick={createNewChatSession}
                          size="sm"
                          className="bg-blue-500 hover:bg-blue-600 text-white"
                        >
                          新建
                        </Button>
                        <Button
                          onClick={toggleSelectionMode}
                          size="sm"
                          variant="outline"
                          className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50 hover:text-white"
                        >
                          管理
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          onClick={toggleSelectAll}
                          size="sm"
                          variant="outline"
                          className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50 hover:text-white"
                        >
                          {selectedSessions.size === chatSessions.length ? (
                            <>
                              <Square className="mr-1 h-3 w-3" />
                              全不选
                            </>
                          ) : (
                            <>
                              <CheckSquare className="mr-1 h-3 w-3" />
                              全选
                            </>
                          )}
                        </Button>
                        <Button
                          onClick={() => setIsSelectionMode(false)}
                          size="sm"
                          variant="outline"
                          className="bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50 hover:text-white"
                        >
                          取消
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                <CardDescription className="text-slate-300">
                  {isSelectionMode ? "选择要删除的对话" : "点击切换到不同的对话会话"}
                </CardDescription>

                {/* 批量操作按钮 */}
                {isSelectionMode && (
                  <div className="flex gap-2 mt-4">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="destructive"
                          disabled={selectedSessions.size === 0}
                          className="flex-1"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          删除选中 ({selectedSessions.size})
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-slate-800 border-slate-700">
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-white">确认删除</AlertDialogTitle>
                          <AlertDialogDescription className="text-slate-300">
                            您确定要删除选中的 {selectedSessions.size} 个对话吗？此操作无法撤销。
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600">
                            取消
                          </AlertDialogCancel>
                          <AlertDialogAction onClick={deleteSelectedSessions} className="bg-red-600 hover:bg-red-700">
                            删除
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="destructive" className="flex-1">
                          <AlertTriangle className="mr-2 h-4 w-4" />
                          清空全部
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-slate-800 border-slate-700">
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-white">清空所有历史对话</AlertDialogTitle>
                          <AlertDialogDescription className="text-slate-300">
                            您确定要清空所有历史对话吗？此操作将删除所有对话记录，无法撤销。
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600">
                            取消
                          </AlertDialogCancel>
                          <AlertDialogAction onClick={clearAllChatSessions} className="bg-red-600 hover:bg-red-700">
                            清空全部
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px] pr-4">
                  {chatSessions.length === 0 ? (
                    <div className="text-center text-slate-400 py-8">
                      <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>暂无对话历史</p>
                      <Button
                        onClick={createNewChatSession}
                        size="sm"
                        className="mt-4 bg-blue-500 hover:bg-blue-600 text-white"
                      >
                        开始新对话
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {chatSessions.map((session) => (
                        <div
                          key={session.id}
                          className={`p-3 rounded-lg border transition-colors group ${
                            session.id === currentSessionId
                              ? "bg-blue-500/20 border-blue-500/50"
                              : "bg-slate-700/30 border-slate-600 hover:border-slate-500"
                          } ${isSelectionMode ? "cursor-pointer" : "cursor-pointer"}`}
                          onClick={() => {
                            if (isSelectionMode) {
                              toggleSessionSelection(session.id)
                            } else {
                              switchChatSession(session.id)
                            }
                          }}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3 flex-1 min-w-0">
                              {isSelectionMode && (
                                <div className="mt-1">
                                  {selectedSessions.has(session.id) ? (
                                    <CheckSquare className="h-4 w-4 text-blue-400" />
                                  ) : (
                                    <Square className="h-4 w-4 text-slate-400" />
                                  )}
                                </div>
                              )}
                              <div className="flex-1 min-w-0">
                                <p className="text-white text-sm font-medium truncate">{session.title}</p>
                                <p className="text-slate-400 text-xs mt-1">{session.timestamp}</p>
                                {session.messages.length > 0 && (
                                  <p className="text-slate-500 text-xs mt-1 truncate">
                                    {session.messages.length} 条消息
                                  </p>
                                )}
                              </div>
                            </div>
                            {!isSelectionMode && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  deleteChatSession(session.id)
                                }}
                                className="opacity-0 group-hover:opacity-100 transition-opacity text-red-400 hover:text-red-300 hover:bg-red-500/10 p-1 h-auto"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
